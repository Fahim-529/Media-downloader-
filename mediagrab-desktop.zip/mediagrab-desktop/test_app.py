import os, sys, tempfile, time, unittest
os.environ["MEDIAGRAB_NO_UPDATE"] = "1"
import app as A

REAL_YDL = A.yt_dlp.YoutubeDL

class FakeYDL:
    last_opts = None
    def __init__(self, opts): self.o = opts; FakeYDL.last_opts = opts
    def __enter__(self): return self
    def __exit__(self, *a): return False
    def extract_info(self, url, download=True):
        if "boom" in url: raise Exception("ERROR: Video unavailable")
        if "playlist" in url: return {"_type": "playlist", "title": "pl"}
        if "pin/img" in url:
            return {"id": "77", "title": "", "formats": [], "thumbnails": [
                {"url": "https://i.pinimg.com/236x/a.jpg", "width": 236, "height": 300},
                {"url": "https://i.pinimg.com/originals/a/b/c.jpg", "width": 1080, "height": 1350}]}
        if "pin/vid" in url:
            return {"id": "88", "title": "Vid pin", "duration": 8, "formats": [
                {"url": "https://v1.pinimg.com/a.mp4", "format_id": "V_720P", "height": 720, "vcodec": None, "acodec": None},
                {"url": "https://v1.pinimg.com/b.mp4", "format_id": "V_360P", "height": 360, "vcodec": None, "acodec": None}]}
        info = {"title": "Clip", "uploader": "chan", "duration": 125,
                "formats": [{"vcodec": "av01", "height": 2160, "fps": 60}, {"vcodec": "vp9", "height": 1080, "fps": 30},
                            {"vcodec": "avc1", "height": 720, "fps": 30}, {"vcodec": "none", "acodec": "opus"}]}
        if download:
            p = os.path.join(self.o["paths"]["home"], "Clip [abc].mp4")
            open(p, "wb").write(b"x")
            self.o["progress_hooks"][0]({"status": "downloading", "downloaded_bytes": 50, "total_bytes": 100, "speed": 10, "eta": 5})
            self.o["postprocessor_hooks"][0]({"status": "started", "postprocessor": "Merger"})
            info["requested_downloads"] = [{"filepath": p}]
        return info

class Pure(unittest.TestCase):
    def test_good_urls(self):
        for u in ["https://www.youtube.com/watch?v=x", "https://youtu.be/x", "https://m.youtube.com/watch?v=1",
                  "https://music.youtube.com/watch?v=1", "https://www.pinterest.com/pin/1/", "https://in.pinterest.com/pin/1/",
                  "https://www.pinterest.co.uk/pin/1/", "https://pin.it/abc"]:
            self.assertEqual(A.validate_url(f" {u} "), u)
    def test_bad_urls(self):
        for u in ["", "https://evil.com", "https://youtube.com.evil.com/x", "https://evilyoutube.com", "https://notpinterest.com/pin/1",
                  "https://pinterest.com.evil.io/x", "https://pinterest.xx/pin/1", "file:///etc/passwd", "http://127.0.0.1/x",
                  "https://user:pw@youtube.com/x", "https://youtube.com/x y", "ftp://youtube.com/x", "javascript:alert(1)",
                  "https://youtube.com/" + "a" * 3000, "http://169.254.169.254/"]:
            with self.assertRaises(ValueError, msg=u): A.validate_url(u)
    def test_unrestricted_mode_still_blocks_local(self):
        A.RESTRICT_SITES = False
        try:
            self.assertEqual(A.validate_url("https://vimeo.com/1"), "https://vimeo.com/1")
            for u in ["http://localhost/x", "http://10.0.0.1/x", "http://[::1]/x", "file:///c:/x"]:
                with self.assertRaises(ValueError): A.validate_url(u)
        finally: A.RESTRICT_SITES = True
    def test_folder(self):
        with tempfile.TemporaryDirectory() as d: self.assertEqual(A.validate_folder(d), os.path.abspath(d))
        with self.assertRaises(ValueError): A.validate_folder("/nope/nope")
    def test_labels(self):
        self.assertEqual(A.height_label(2160), "2160p (4K)"); self.assertEqual(A.height_label(1080), "1080p (Full HD)")
        self.assertEqual(A.height_label(540), "540p"); self.assertEqual(A.parse_height("1440p (2K)"), 1440)
        self.assertIsNone(A.parse_height("Audio only"))
    def test_items(self):
        it = A.build_resolution_items([720, 2160, 1080], 2160, 60)
        self.assertEqual([i[2] for i in it[:4]], [None, 2160, 1080, 720]); self.assertIn("60fps", it[0][0])
        self.assertEqual([i[1] for i in it[-2:]], ["mp3", "audio"])
        self.assertEqual([i[1] for i in A.build_resolution_items(has_video=False)], ["mp3", "audio"])
    def test_options(self):
        o = A.build_options("video", None, "mp4", "/tmp/100%_x", "/ff")
        self.assertEqual(o["format"], "bv*+ba/b"); self.assertEqual(o["merge_output_format"], "mp4")
        self.assertEqual(o["paths"]["home"], "/tmp/100%_x")
        o = A.build_options("video", 1080, "mp4", "/t", "/ff"); self.assertIn("height=1080][vcodec^=avc1]", o["format"])
        o = A.build_options("video", 2160, "mkv", "/t", "/ff"); self.assertEqual(o["merge_output_format"], "mkv")
        self.assertIn("height<=2160", o["format"])
        self.assertNotIn("+", A.build_options("video", 1080, "mp4", "/t", None)["format"])   # no ffmpeg: single files
        self.assertTrue(A.build_options("mp3", None, "mp4", "/t", "/ff")["postprocessors"])
        self.assertNotIn("postprocessors", A.build_options("mp3", None, "mp4", "/t", None))
        self.assertEqual(A.build_options("audio", None, "mp4", "/t", "/ff")["format"], "bestaudio/best")
        for m in ("video", "mp3", "audio"):
            oo = A.build_options(m, 720, "mp4", "/t", "/ff")
            self.assertEqual(oo["allowed_extractors"], ["youtube", "pinterest"]); self.assertTrue(oo["noplaylist"])
            self.assertTrue(oo["windowsfilenames"]); self.assertFalse(oo["nocheckcertificate"])
            self.assertNotIn("cookiesfrombrowser", oo)
    def test_real_ytdlp_accepts_options(self):
        for m in ("video", "mp3", "audio"):
            with REAL_YDL(A.build_options(m, 720, "mp4", tempfile.gettempdir(), None)) as y:
                self.assertTrue(y.params["noplaylist"])
    def test_summarize(self):
        s = A.summarize_info(FakeYDL({}).extract_info("https://youtu.be/a", download=False))
        self.assertEqual((s["best_h"], s["best_fps"], s["heights"]), (2160, 60, [2160, 1080, 720]))
        self.assertTrue(A.summarize_info({"_type": "playlist"})["playlist"])
    def test_pinit_redirect_is_validated(self):
        h = A._CheckedRedirect()
        with self.assertRaises(ValueError):
            h.redirect_request(None, None, 302, "", {}, "https://evil.com/x")
    def test_js_runtime_option(self):
        orig = A.find_js_runtime
        try:
            A.find_js_runtime = lambda: ("deno", "C:/x/bin/deno.exe")
            o = A.build_options("video", None, "mp4", "/t", "/ff")
            self.assertEqual(o["js_runtimes"], {"deno": {"path": "C:/x/bin/deno.exe"}})
            with REAL_YDL(A.build_options("video", None, "mp4", tempfile.gettempdir(), None)) as y:
                self.assertIn("deno", y.params["js_runtimes"])
            A.find_js_runtime = lambda: None
            self.assertNotIn("js_runtimes", A.build_options("video", None, "mp4", "/t", "/ff"))
            self.assertIn("Deno", A.friendly_error(Exception("ERROR: [youtube] x: Requested format is not available.")))
            A.find_js_runtime = lambda: ("deno", "p")
            self.assertIn("hid the formats", A.friendly_error(Exception("Requested format is not available")))
            self.assertEqual(A.friendly_error(Exception("boom")), "boom")
        finally:
            A.find_js_runtime = orig
    def test_info_uses_permissive_format(self):
        class Spy(FakeYDL): pass
        A.yt_dlp.YoutubeDL = Spy
        try:
            class Dummy:  # minimal stand-in for the App instance
                ffmpeg_dir = None
            real, s = A.App._fetch_info(Dummy(), "https://youtu.be/abc")
            self.assertEqual(Spy.last_opts["format"], "all"); self.assertTrue(Spy.last_opts["ignore_no_formats_error"])
            self.assertTrue(s["has_video"] and s["has_audio"])
        finally:
            A.yt_dlp.YoutubeDL = REAL_YDL
    def test_pinterest_video_without_codecs_is_video(self):
        with REAL_YDL({"quiet": True, "format": "all", "ignore_no_formats_error": True}) as y:
            r = y.process_ie_result({"id": "1", "title": "t", "extractor": "pinterest", "extractor_key": "Pinterest",
                                     "webpage_url": "https://www.pinterest.com/pin/1/",
                                     "formats": [{"url": "https://v1.pinimg.com/a.mp4", "format_id": "V_720P", "height": 720}]},
                                    download=False)
        s = A.summarize_info(r)
        self.assertTrue(s["has_video"]); self.assertEqual(s["heights"], [720]); self.assertIsNone(s["image"])
    def test_pinterest_image_pin(self):
        s = A.summarize_info(FakeYDL({}).extract_info("https://www.pinterest.com/pin/img/", download=False))
        self.assertFalse(s["has_video"]); self.assertFalse(s["has_audio"])
        self.assertEqual(s["image"], {"url": "https://i.pinimg.com/originals/a/b/c.jpg", "width": 1080, "height": 1350})
        it = A.build_resolution_items(image=s["image"])
        self.assertEqual(len(it), 1); self.assertEqual(it[0][1], "image"); self.assertIn("1080x1350", it[0][0])
        # thumbnails from other hosts are never used
        self.assertIsNone(A.best_image({"thumbnails": [{"url": "https://evil.com/x.jpg", "width": 9999, "height": 9999}]}))
        self.assertIsNone(A.best_image({"thumbnails": [{"url": "http://i.pinimg.com/x.jpg", "width": 9, "height": 9}]}))
        self.assertFalse(A.image_host_ok("https://pinimg.com.evil.com/x.jpg"))
    def test_download_image(self):
        import io, email.message
        class Resp(io.BytesIO):
            def __init__(self, data, ctype, length=None):
                super().__init__(data); self.headers = email.message.Message()
                self.headers["Content-Type"] = ctype
                self.headers["Content-Length"] = str(len(data) if length is None else length)
            def __enter__(self): return self
            def __exit__(self, *a): return False
        class Op:
            def __init__(self, r): self.r = r
            def open(self, req, timeout=0): return self.r
        d = tempfile.mkdtemp(); u = "https://i.pinimg.com/originals/a.jpg"
        p = A.download_image(u, d, "pin [1]", opener=Op(Resp(b"JPEGDATA", "image/jpeg")))
        self.assertEqual(os.path.basename(p), "pin [1].jpg"); self.assertEqual(open(p, "rb").read(), b"JPEGDATA")
        p2 = A.download_image(u, d, "pin [1]", opener=Op(Resp(b"x", "image/jpeg")))
        self.assertEqual(os.path.basename(p2), "pin [1] (1).jpg")                      # never overwrites
        with self.assertRaises(ValueError): A.download_image("https://evil.com/a.jpg", d, "x", opener=Op(Resp(b"x", "image/jpeg")))
        with self.assertRaises(ValueError): A.download_image(u, d, "x", opener=Op(Resp(b"<html>", "text/html")))
        with self.assertRaises(ValueError): A.download_image(u, d, "x", opener=Op(Resp(b"x", "image/png", length=A.MAX_IMAGE + 1)))
        ev = A.threading.Event(); ev.set()
        with self.assertRaises(A.DownloadCancelled): A.download_image(u, d, "c", cancel=ev, opener=Op(Resp(b"x", "image/png")))
        self.assertFalse([f for f in os.listdir(d) if f.endswith(".part")])           # no leftovers
        self.assertEqual(A.safe_name("a/b\\c:d*e?"), A.safe_name("a/b\\c:d*e?"))
        self.assertNotIn("/", A.safe_name("../../etc/passwd"))
        with self.assertRaises(ValueError):
            A._ImgRedirect().redirect_request(None, None, 302, "", {}, "https://evil.com/x.jpg")
    def test_plugins_disabled(self):
        self.assertEqual(os.environ["YTDLP_NO_PLUGINS"], "1")

@unittest.skipUnless(os.environ.get("MG_GUI_TEST") == "1", "needs a display")
class Gui(unittest.TestCase):
    def pump(self, app, cond, secs=5):
        end = time.time() + secs
        while time.time() < end and not cond():
            app.update(); time.sleep(0.02)
        return cond()
    def test_flow(self):
        A.yt_dlp.YoutubeDL = FakeYDL
        try:
            app = A.App(); app.ffmpeg_dir = "/ff"
            d = tempfile.mkdtemp(); app.folder.set(d)
            app.url.set("https://youtu.be/abc"); app.check()
            self.assertTrue(self.pump(app, lambda: not app.busy))
            labels = list(app.res_box.cget("values"))
            self.assertTrue(labels[0].startswith("Best available (2160p 60fps)")); self.assertIn("1080p (Full HD)", labels)
            self.assertNotIn("1440p (2K)", labels)                    # only real resolutions are offered
            app.res.set("1080p (Full HD)"); app._sync_container()
            app.start(); self.assertTrue(app.busy)
            self.assertTrue(self.pump(app, lambda: not app.busy))
            self.assertEqual(app.status.get(), "Done - download finished")
            self.assertIn(os.path.join(d, "Clip [abc].mp4"), [app.last_file]); self.assertTrue(os.path.isfile(app.last_file))
            self.assertIn("1080", FakeYDL.last_opts["format"])
            app.res.set(A.AUDIO_MP3); app._sync_container(); self.assertEqual(str(app.cont_box.cget("state")), "disabled")
            app.url.set("https://evil.com/x"); import tkinter.messagebox as mb; shown = []
            mb.showerror = lambda *a, **k: shown.append(a[1]); app.start()
            self.assertFalse(app.busy); self.assertTrue(shown)
            app.url.set("https://youtu.be/playlist"); app.check(); self.pump(app, lambda: not app.busy)
            self.assertIn("playlist", app.logbox.get("1.0", "end").lower())
            # Pinterest image pin: check -> image option -> download saves the file
            app.url.set("https://www.pinterest.com/pin/img/"); app.check()
            self.assertTrue(self.pump(app, lambda: not app.busy))
            self.assertEqual(list(app.res_box.cget("values")), ["Image - original quality (1080x1350)"])
            self.assertIn("Image pin", app.v_best.get())
            def fake_dl(url, folder, base, progress=None, cancel=None, opener=None):
                p = os.path.join(folder, base + ".jpg"); open(p, "wb").close(); progress(5, 10); return p
            orig_dl = A.download_image; A.download_image = fake_dl
            try:
                app.start(); self.assertTrue(app.busy)
                self.assertTrue(self.pump(app, lambda: not app.busy))
            finally: A.download_image = orig_dl
            self.assertEqual(app.status.get(), "Done - image saved")
            self.assertTrue(app.last_file.endswith("pin [77].jpg") and os.path.isfile(app.last_file))
            # Pinterest video pin: heights are listed even though codecs are unknown
            app.url.set("https://www.pinterest.com/pin/vid/"); app.check()
            self.assertTrue(self.pump(app, lambda: not app.busy))
            self.assertEqual(list(app.res_box.cget("values"))[1:3], ["720p (HD)", "360p"])
            app.destroy()
        finally:
            A.yt_dlp.YoutubeDL = REAL_YDL

if __name__ == "__main__":
    unittest.main()
