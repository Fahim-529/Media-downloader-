"""
MediaGrab - desktop video/audio downloader (YouTube + Pinterest) built on yt-dlp.

No server, no ports, no background process: it is just a window. Close the window and
everything is gone.

Security design:
  * yt-dlp is used as a LIBRARY (no shell, no user-supplied command-line arguments).
  * yt-dlp plugin loading is disabled (plugins are arbitrary code).
  * Only http/https links to YouTube / Pinterest are accepted (see RESTRICT_SITES);
    pin.it short links are resolved by us with every redirect re-validated.
  * Fixed filename template, Windows-safe names, files stay in the folder you chose.
  * TLS verification ON, browser cookies never read, no telemetry.
"""
import os
import sys

os.environ["YTDLP_NO_PLUGINS"] = "1"          # must be set BEFORE importing yt_dlp

import ipaddress
import json
import queue
import re
import shutil
import subprocess
import threading
import time
import urllib.request
from urllib.parse import urlparse

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

APP = "MediaGrab"
FROZEN = getattr(sys, "frozen", False)
HERE = os.path.dirname(os.path.abspath(sys.executable if FROZEN else __file__))
BUNDLE = getattr(sys, "_MEIPASS", HERE)
CONFIG = os.path.join(os.path.expanduser("~"), ".mediagrab.json")

# True  = only YouTube + Pinterest links (safest, what you asked for)
# False = any public http(s) site that yt-dlp supports
RESTRICT_SITES = True
MAX_URL_LEN = 2048


def _maybe_update_ytdlp():
    """Source installs only: refresh yt-dlp at most once per 24h (sites change constantly)."""
    if FROZEN or os.environ.get("MEDIAGRAB_NO_UPDATE"):
        return
    stamp = os.path.join(HERE, ".last_update")
    try:
        if time.time() - os.path.getmtime(stamp) < 86400:
            return
    except OSError:
        pass
    try:
        subprocess.run([sys.executable, "-m", "pip", "install", "-U", "-q", "yt-dlp"],
                       timeout=90, check=False, capture_output=True,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        open(stamp, "w").close()
    except Exception:  # noqa: BLE001 - offline etc.: never block starting
        pass


_maybe_update_ytdlp()
import yt_dlp                                   # noqa: E402
from yt_dlp.utils import DownloadCancelled      # noqa: E402

# --------------------------------------------------------------------------
# Pure helpers (unit-testable without a GUI)
# --------------------------------------------------------------------------
_PIN_TLDS = "com|co\\.uk|com\\.au|ca|fr|de|es|it|jp|nl|pt|se|ch|at|ie|dk|nz|ph|mx|cl|pl|kr"
_PIN_RE = re.compile(rf"(?:[a-z0-9-]+\.)*pinterest\.(?:{_PIN_TLDS})")


def host_allowed(host):
    h = (host or "").lower().rstrip(".")
    if h in ("youtu.be", "pin.it", "youtube.com") or h.endswith(".youtube.com"):
        return True
    return bool(_PIN_RE.fullmatch(h))


def validate_url(raw):
    url = (raw or "").strip()
    if not url:
        raise ValueError("Please paste a link first.")
    if len(url) > MAX_URL_LEN:
        raise ValueError("That link is too long.")
    if any(ord(c) < 32 or ord(c) == 127 or c.isspace() for c in url):
        raise ValueError("The link contains spaces or control characters.")
    p = urlparse(url)
    if p.scheme.lower() not in ("http", "https"):
        raise ValueError("Only http:// and https:// links are allowed.")
    host = (p.hostname or "").lower()
    if not host:
        raise ValueError("The link has no host name.")
    if p.username or p.password:
        raise ValueError("Links with embedded usernames/passwords are blocked.")
    if RESTRICT_SITES:
        if not host_allowed(host):
            raise ValueError("Only YouTube and Pinterest links are supported.")
    else:
        if host == "localhost" or host.endswith((".localhost", ".local", ".internal")):
            raise ValueError("Local addresses are blocked.")
        try:
            ip = ipaddress.ip_address(host)
        except ValueError:
            ip = None
        if ip and (ip.is_private or ip.is_loopback or ip.is_link_local
                   or ip.is_reserved or ip.is_multicast or ip.is_unspecified):
            raise ValueError("Private / local IP addresses are blocked.")
    return url


class _CheckedRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        validate_url(newurl)                       # every hop must stay allowed
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def resolve_short(url):
    """Resolve pin.it short links safely; other links pass through unchanged."""
    if (urlparse(url).hostname or "").lower() != "pin.it":
        return url
    opener = urllib.request.build_opener(_CheckedRedirect)
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with opener.open(req, timeout=10) as r:
        return validate_url(r.geturl())


def validate_folder(path):
    path = os.path.abspath((path or "").strip())
    if not os.path.isdir(path):
        raise ValueError("The save folder does not exist.")
    if not os.access(path, os.W_OK):
        raise ValueError("The save folder is not writable.")
    return path


def find_ffmpeg_dir():
    for d in (os.path.join(HERE, "bin"), BUNDLE, HERE):
        if os.path.isfile(os.path.join(d, "ffmpeg.exe")) or os.path.isfile(os.path.join(d, "ffmpeg")):
            return d
    exe = shutil.which("ffmpeg")
    return os.path.dirname(exe) if exe else None


def find_js_runtime():
    """YouTube needs a JavaScript runtime (Deno preferred) to expose video formats."""
    for d in (os.path.join(HERE, "bin"), BUNDLE, HERE):
        for exe in ("deno.exe", "deno"):
            p = os.path.join(d, exe)
            if os.path.isfile(p):
                return "deno", p
    for name in ("deno", "node", "bun"):
        p = shutil.which(name)
        if p:
            return name, p
    return None


def friendly_error(ex):
    msg = clean_error(ex)
    if "Requested format is not available" in msg or "No downloadable formats" in msg:
        if not find_js_runtime():
            return (msg + "\n-> YouTube needs the JavaScript helper (Deno), which is missing. "
                          "Close MediaGrab and double-click MediaGrab.bat again to install it.")
        return (msg + "\n-> YouTube hid the formats for this video. Try again later, or delete the "
                      "'.last_update' file and relaunch to refresh yt-dlp. (Private, age-restricted "
                      "or region-blocked videos can also cause this.)")
    return msg


_NAMES = {4320: "8K", 2160: "4K", 1440: "2K", 1080: "Full HD", 720: "HD"}


def height_label(h):
    return f"{h}p ({_NAMES[h]})" if h in _NAMES else f"{h}p"


def parse_height(label):
    m = re.match(r"(\d+)p", label or "")
    return int(m.group(1)) if m else None


DEFAULT_HEIGHTS = [2160, 1440, 1080, 720, 480, 360]
AUDIO_MP3 = "Audio only - MP3 320 kbps"
AUDIO_ORIG = "Audio only - original quality (M4A/Opus)"


def build_resolution_items(heights=None, best_h=0, best_fps=0, has_video=True, image=None):
    """List of (label, mode, height). Real heights come from the checked video."""
    if image:
        size = f" ({image['width']}x{image['height']})" if image.get("width") else ""
        return [(f"Image - original quality{size}", "image", None)]
    items = []
    if has_video:
        hs = sorted(set(heights or DEFAULT_HEIGHTS), reverse=True)
        if best_h:
            fps = f" {int(best_fps)}fps" if best_fps and best_fps > 30 else ""
            items.append((f"Best available ({best_h}p{fps})", "video", None))
        else:
            items.append(("Best available", "video", None))
        items += [(height_label(h), "video", h) for h in hs]
    items += [(AUDIO_MP3, "mp3", None), (AUDIO_ORIG, "audio", None)]
    return items


def build_options(mode, height, container, folder, ffmpeg_dir):
    """yt-dlp options. Nothing here comes from free text."""
    o = {
        "paths": {"home": folder},
        "outtmpl": "%(title).150B [%(id)s].%(ext)s",
        "windowsfilenames": True,
        "noplaylist": True,
        "overwrites": False,
        "quiet": True, "no_warnings": True, "noprogress": True,
        "socket_timeout": 20, "retries": 5, "fragment_retries": 5,
        "enable_file_urls": False,
        "nocheckcertificate": False,
    }
    if RESTRICT_SITES:
        o["allowed_extractors"] = ["youtube", "pinterest"]
    if ffmpeg_dir:
        o["ffmpeg_location"] = ffmpeg_dir
    rt = find_js_runtime()
    if rt:
        o["js_runtimes"] = {rt[0]: {"path": rt[1]}}
    cap = f"[height<={height}]" if height else ""
    if mode == "video":
        if ffmpeg_dir:
            if container == "mkv":
                o["format"] = f"bv*{cap}+ba/b{cap}"
                o["merge_output_format"] = "mkv"
            else:
                if height:   # prefer widely playable H.264/AAC at exactly that height
                    o["format"] = (f"bv*[height={height}][vcodec^=avc1]+ba[acodec^=mp4a]/"
                                   f"bv*{cap}+ba/b{cap}")
                else:        # best available, whatever the codec, muxed into MP4
                    o["format"] = "bv*+ba/b"
                o["merge_output_format"] = "mp4"
        else:                # no ffmpeg: only ready-made single files
            o["format"] = f"b{cap}[ext=mp4]/b{cap}/b"
    elif mode == "mp3" and ffmpeg_dir:
        o["format"] = "bestaudio/best"
        o["postprocessors"] = [{"key": "FFmpegExtractAudio",
                                "preferredcodec": "mp3", "preferredquality": "320"}]
    else:
        o["format"] = "bestaudio/best"
    return o


def clean_error(ex):
    return re.sub(r"\x1b\[[0-9;]*m", "", str(ex)).replace("ERROR: ", "").strip()[:400]


def fmt_bytes(n):
    n = float(n or 0)
    for u in ("B", "KB", "MB", "GB"):
        if n < 1024 or u == "GB":
            return f"{int(n)} B" if u == "B" else f"{n:.1f} {u}"
        n /= 1024


def _is_video(f):
    ve = f.get("video_ext")                       # set by yt-dlp; reliable even when codecs are unknown
    if ve is not None:
        return ve != "none"
    return f.get("vcodec") != "none" and bool(f.get("vcodec") or f.get("height"))


def _is_audio(f):
    ae = f.get("audio_ext")
    if ae is not None and ae != "none":
        return True
    ac = f.get("acodec")
    return ac not in (None, "none")


def image_host_ok(url):
    try:
        p = urlparse(url or "")
    except ValueError:
        return False
    h = (p.hostname or "").lower()
    return p.scheme == "https" and (h == "pinimg.com" or h.endswith(".pinimg.com"))


def best_image(info):
    """Largest Pinterest image listed in the pin data (the 'orig' size), or None."""
    best, area = None, -1
    for t in info.get("thumbnails") or []:
        u = t.get("url")
        if not image_host_ok(u):
            continue
        a = (t.get("width") or 0) * (t.get("height") or 0)
        if a >= area:
            best, area = t, a
    if not best:
        return None
    return {"url": best["url"], "width": int(best.get("width") or 0), "height": int(best.get("height") or 0)}


IMG_EXT = {"image/jpeg": ".jpg", "image/png": ".png", "image/gif": ".gif", "image/webp": ".webp"}
MAX_IMAGE = 100 * 1024 * 1024


class _ImgRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if not image_host_ok(newurl):
            raise ValueError("Blocked redirect to a non-Pinterest image host.")
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def safe_name(text, fallback="download"):
    from yt_dlp.utils import sanitize_filename
    n = sanitize_filename(text or "", restricted=False)[:150].strip(" .")
    return n or fallback


def unique_path(folder, base, ext):
    p = os.path.join(folder, base + ext)
    i = 1
    while os.path.exists(p):
        p = os.path.join(folder, f"{base} ({i}){ext}")
        i += 1
    if os.path.dirname(os.path.abspath(p)) != os.path.abspath(folder):
        raise ValueError("Unsafe file name.")
    return p


def download_image(url, folder, base, progress=None, cancel=None, opener=None):
    """Download one Pinterest image (host-checked, size-capped, type-checked)."""
    if not image_host_ok(url):
        raise ValueError("Blocked image host.")
    folder = validate_folder(folder)
    op = opener or urllib.request.build_opener(_ImgRedirect)
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with op.open(req, timeout=20) as r:
        ctype = (r.headers.get_content_type() or "").lower()
        if ctype not in IMG_EXT:
            raise ValueError("The link did not return an image.")
        total = int(r.headers.get("Content-Length") or 0)
        if total > MAX_IMAGE:
            raise ValueError("Image is too large.")
        path = unique_path(folder, base, IMG_EXT[ctype])
        tmp = path + ".part"
        got = 0
        try:
            with open(tmp, "wb") as f:
                while True:
                    if cancel is not None and cancel.is_set():
                        raise DownloadCancelled("Cancelled by user")
                    chunk = r.read(65536)
                    if not chunk:
                        break
                    got += len(chunk)
                    if got > MAX_IMAGE:
                        raise ValueError("Image is too large.")
                    f.write(chunk)
                    if progress:
                        progress(got, total)
            os.replace(tmp, path)
        finally:
            if os.path.exists(tmp):
                os.remove(tmp)
    return path


def summarize_info(info):
    allf = info.get("formats") or []
    fm = [f for f in allf if _is_video(f)]
    heights = sorted({int(f["height"]) for f in fm if f.get("height")}, reverse=True)
    best_h = heights[0] if heights else 0
    best_fps = max([f.get("fps") or 0 for f in fm if f.get("height") == best_h], default=0)
    has_audio = any(_is_audio(f) for f in allf)
    image = best_image(info) if not fm and not has_audio else None
    return dict(title=str(info.get("title") or "(untitled)"), has_audio=has_audio,
                image=image, vid=str(info.get("id") or ""),
                uploader=str(info.get("uploader") or ""),
                duration=int(info.get("duration") or 0),
                heights=heights, best_h=best_h, best_fps=best_fps,
                has_video=bool(fm), live=bool(info.get("is_live")),
                playlist=info.get("_type") == "playlist")


# --------------------------------------------------------------------------
# GUI
# --------------------------------------------------------------------------
BG, PANEL, FG, MUTED, ACC, ERR = "#12151c", "#1a1f2b", "#e6e9f0", "#8b94a8", "#27e0a3", "#ff6b6b"


class QuietLogger:
    def __init__(self, sink):
        self.sink = sink
    def debug(self, m): pass
    def info(self, m): pass
    def warning(self, m): self.sink(f"Warning: {m}")
    def error(self, m): self.sink(f"Error: {friendly_error(m)}")


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"{APP} - YouTube & Pinterest downloader")
        self.geometry("780x680")
        self.minsize(700, 620)
        self.configure(bg=BG)
        self.q = queue.Queue()
        self.cancel_event = threading.Event()
        self.busy = False
        self.ffmpeg_dir = find_ffmpeg_dir()
        if self.ffmpeg_dir:
            os.environ["PATH"] = self.ffmpeg_dir + os.pathsep + os.environ.get("PATH", "")
        self.items = build_resolution_items()
        self.info_url = None
        self.image_for, self.image_info = None, None
        self.last_file = None
        self._style()
        self._build()
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self.after(100, self._drain)
        self.log(f"Ready. yt-dlp {yt_dlp.version.__version__}")
        if not find_js_runtime():
            self.log("JavaScript helper (Deno) not found: YouTube will show few or no formats. "
                     "Close this window and double-click MediaGrab.bat to install it.")
        if not self.ffmpeg_dir:
            self.log("ffmpeg not found: resolutions above ~720p and MP3 need it. "
                     "Run MediaGrab.bat once (it downloads ffmpeg) or install ffmpeg.")

    # ---- look
    def _style(self):
        st = ttk.Style(self)
        st.theme_use("clam")
        st.configure(".", background=BG, foreground=FG, fieldbackground=PANEL, bordercolor="#252b3b",
                     lightcolor=BG, darkcolor=BG, troughcolor=PANEL, font=("Segoe UI", 10))
        st.configure("TFrame", background=BG)
        st.configure("Card.TFrame", background=PANEL)
        st.configure("TLabel", background=BG, foreground=FG)
        st.configure("Muted.TLabel", foreground=MUTED)
        st.configure("Title.TLabel", font=("Segoe UI", 20, "bold"))
        st.configure("Info.TLabel", background=PANEL, foreground=FG)
        st.configure("Badge.TLabel", background=PANEL, foreground=ACC, font=("Segoe UI", 10, "bold"))
        st.configure("TEntry", padding=6, insertcolor=FG)
        st.configure("TCombobox", padding=5, arrowcolor=FG)
        st.map("TCombobox", fieldbackground=[("readonly", PANEL)], foreground=[("readonly", FG)])
        st.configure("TButton", padding=(14, 7), background=PANEL, foreground=FG)
        st.map("TButton", background=[("active", "#232a3a"), ("disabled", BG)],
               foreground=[("disabled", MUTED)])
        st.configure("Accent.TButton", background=ACC, foreground="#04120d", font=("Segoe UI", 10, "bold"))
        st.map("Accent.TButton", background=[("active", "#4af0b9"), ("disabled", "#1b5a47")],
               foreground=[("disabled", "#0a2a20")])
        st.configure("Horizontal.TProgressbar", background=ACC, troughcolor=PANEL, thickness=10)
        self.option_add("*TCombobox*Listbox.background", PANEL)
        self.option_add("*TCombobox*Listbox.foreground", FG)
        self.option_add("*TCombobox*Listbox.selectBackground", ACC)
        self.option_add("*TCombobox*Listbox.selectForeground", "#04120d")

    # ---- layout
    def _build(self):
        root = ttk.Frame(self, padding=18)
        root.pack(fill="both", expand=True)
        root.columnconfigure(0, weight=1)

        ttk.Label(root, text="MediaGrab", style="Title.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(root, text="Paste a YouTube or Pinterest link, choose quality and folder, press Download.",
                  style="Muted.TLabel").grid(row=1, column=0, sticky="w", pady=(0, 12))

        row = ttk.Frame(root)
        row.grid(row=2, column=0, sticky="ew")
        row.columnconfigure(0, weight=1)
        self.url = tk.StringVar()
        self.url_entry = ttk.Entry(row, textvariable=self.url)
        self.url_entry.grid(row=0, column=0, sticky="ew")
        self.url_entry.bind("<Return>", lambda _e: self.check())
        self.url_entry.focus()
        ttk.Button(row, text="Paste", command=self.paste).grid(row=0, column=1, padx=(8, 0))
        self.btn_check = ttk.Button(row, text="Check link", command=self.check)
        self.btn_check.grid(row=0, column=2, padx=(8, 0))

        card = ttk.Frame(root, style="Card.TFrame", padding=14)
        card.grid(row=3, column=0, sticky="ew", pady=(14, 0))
        card.columnconfigure(0, weight=1)
        self.v_title = tk.StringVar(value="No video checked yet")
        self.v_meta = tk.StringVar(value="Click \"Check link\" to see the available resolutions.")
        self.v_best = tk.StringVar(value="")
        ttk.Label(card, textvariable=self.v_title, style="Info.TLabel", font=("Segoe UI", 11, "bold"),
                  wraplength=700).grid(row=0, column=0, sticky="w")
        ttk.Label(card, textvariable=self.v_meta, style="Info.TLabel", foreground=MUTED).grid(row=1, column=0, sticky="w")
        ttk.Label(card, textvariable=self.v_best, style="Badge.TLabel").grid(row=2, column=0, sticky="w")

        opts = ttk.Frame(root)
        opts.grid(row=4, column=0, sticky="ew", pady=(14, 0))
        opts.columnconfigure(0, weight=3)
        opts.columnconfigure(1, weight=2)
        ttk.Label(opts, text="Resolution / type", style="Muted.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(opts, text="Video format", style="Muted.TLabel").grid(row=0, column=1, sticky="w", padx=(10, 0))
        self.res = tk.StringVar()
        self.res_box = ttk.Combobox(opts, textvariable=self.res, state="readonly")
        self.res_box.grid(row=1, column=0, sticky="ew")
        self.res_box.bind("<<ComboboxSelected>>", lambda _e: self._sync_container())
        self.container = tk.StringVar(value="MP4 (most compatible)")
        self.cont_box = ttk.Combobox(opts, textvariable=self.container, state="readonly",
                                     values=["MP4 (most compatible)", "MKV (keeps best codecs)"])
        self.cont_box.grid(row=1, column=1, sticky="ew", padx=(10, 0))
        self._set_items(self.items)

        ttk.Label(root, text="Save to", style="Muted.TLabel").grid(row=5, column=0, sticky="w", pady=(14, 0))
        frow = ttk.Frame(root)
        frow.grid(row=6, column=0, sticky="ew")
        frow.columnconfigure(0, weight=1)
        self.folder = tk.StringVar(value=self._load_folder())
        ttk.Entry(frow, textvariable=self.folder).grid(row=0, column=0, sticky="ew")
        ttk.Button(frow, text="Browse...", command=self.browse).grid(row=0, column=1, padx=(8, 0))

        bar = ttk.Frame(root)
        bar.grid(row=7, column=0, sticky="ew", pady=(16, 0))
        bar.columnconfigure(0, weight=1)
        self.btn_go = ttk.Button(bar, text="Download", style="Accent.TButton", command=self.start)
        self.btn_go.grid(row=0, column=0, sticky="ew")
        self.btn_cancel = ttk.Button(bar, text="Cancel", command=self.cancel, state="disabled")
        self.btn_cancel.grid(row=0, column=1, padx=(8, 0))
        self.btn_open = ttk.Button(bar, text="Open folder", command=self.open_folder)
        self.btn_open.grid(row=0, column=2, padx=(8, 0))

        self.progress = ttk.Progressbar(root, maximum=100)
        self.progress.grid(row=8, column=0, sticky="ew", pady=(14, 2))
        self.status = tk.StringVar(value="Idle")
        ttk.Label(root, textvariable=self.status, style="Muted.TLabel").grid(row=9, column=0, sticky="w")

        root.rowconfigure(10, weight=1)
        box = ttk.Frame(root)
        box.grid(row=10, column=0, sticky="nsew", pady=(10, 6))
        self.logbox = tk.Text(box, height=7, state="disabled", wrap="word", bg=PANEL, fg=FG,
                              relief="flat", insertbackground=FG, padx=8, pady=6, font=("Consolas", 9))
        sb = ttk.Scrollbar(box, command=self.logbox.yview)
        self.logbox.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.logbox.pack(side="left", fill="both", expand=True)
        ttk.Label(root, text="Only download content you own or have permission to download.",
                  style="Muted.TLabel").grid(row=11, column=0, sticky="w")

    # ---- settings
    def _load_folder(self):
        try:
            with open(CONFIG, encoding="utf-8") as f:
                p = json.load(f).get("folder", "")
            if isinstance(p, str) and os.path.isdir(p):
                return p
        except (OSError, ValueError):
            pass
        d = os.path.join(os.path.expanduser("~"), "Downloads")
        return d if os.path.isdir(d) else os.path.expanduser("~")

    def _save_folder(self, folder):
        try:
            with open(CONFIG, "w", encoding="utf-8") as f:
                json.dump({"folder": folder}, f)
        except OSError:
            pass

    # ---- thread-safe messaging
    def post(self, kind, payload=None):
        self.q.put((kind, payload))

    def _drain(self):
        try:
            while True:
                kind, p = self.q.get_nowait()
                if kind == "log":
                    self.log(p)
                elif kind == "status":
                    self.status.set(p)
                elif kind == "progress":
                    self.progress["value"] = p
                elif kind == "info":
                    self._show_info(p)
                elif kind == "file":
                    self.last_file = p
                elif kind == "done":
                    self.set_busy(False)
                    if p:
                        self.status.set(p)
        except queue.Empty:
            pass
        self.after(100, self._drain)

    def log(self, msg):
        self.logbox.configure(state="normal")
        self.logbox.insert("end", msg + "\n")
        self.logbox.see("end")
        self.logbox.configure(state="disabled")

    def set_busy(self, busy):
        self.busy = busy
        self.btn_go.configure(state="disabled" if busy else "normal")
        self.btn_check.configure(state="disabled" if busy else "normal")
        self.btn_cancel.configure(state="normal" if busy else "disabled")

    # ---- resolution list
    def _set_items(self, items):
        self.items = items
        labels = [i[0] for i in items]
        self.res_box.configure(values=labels)
        self.res.set(labels[0])
        self._sync_container()

    def _selected(self):
        for label, mode, height in self.items:
            if label == self.res.get():
                return mode, height
        return "video", None

    def _sync_container(self):
        mode, _ = self._selected()
        self.cont_box.configure(state="readonly" if mode == "video" else "disabled")

    def _show_info(self, s):
        self.v_title.set(s["title"])
        dur = s["duration"]
        self.v_meta.set(" · ".join(x for x in (s["uploader"], f"{dur // 60}:{dur % 60:02d}" if dur else "") if x))
        if s.get("image"):
            im = s["image"]
            self.v_best.set(f"Image pin - original size {im['width']}x{im['height']}" if im["width"] else "Image pin")
        elif s["has_video"]:
            fps = f" {int(s['best_fps'])}fps" if s["best_fps"] and s["best_fps"] > 30 else ""
            self.v_best.set(f"Highest quality available: {s['best_h']}p{fps}" if s["best_h"] else "Video available")
        else:
            self.v_best.set("Audio-only source")
        self._set_items(build_resolution_items(s["heights"], s["best_h"], s["best_fps"], s["has_video"], s.get("image")))

    # ---- actions
    def paste(self):
        try:
            self.url.set(self.clipboard_get().strip()[:MAX_URL_LEN])
        except tk.TclError:
            pass

    def browse(self):
        d = filedialog.askdirectory(initialdir=self.folder.get() or None)
        if d:
            self.folder.set(d)

    def open_folder(self):
        try:
            folder = validate_folder(self.folder.get())
        except ValueError as ex:
            return messagebox.showerror(APP, str(ex))
        if sys.platform == "win32":
            os.startfile(folder)                      # noqa: S606 - validated directory, no arguments
        elif sys.platform == "darwin":
            subprocess.Popen(["open", folder])
        else:
            subprocess.Popen(["xdg-open", folder])

    def cancel(self):
        self.cancel_event.set()
        self.status.set("Cancelling...")

    def on_close(self):
        if self.busy and not messagebox.askyesno(APP, "A download is in progress.\nCancel it and quit?"):
            return
        self.cancel_event.set()
        self.destroy()
        os._exit(0)          # nothing keeps running after the window is closed

    def _validated(self):
        try:
            return validate_url(self.url.get()), validate_folder(self.folder.get())
        except ValueError as ex:
            messagebox.showerror(APP, str(ex))
            return None

    def check(self):
        if self.busy:
            return
        try:
            url = validate_url(self.url.get())
        except ValueError as ex:
            return messagebox.showerror(APP, str(ex))
        self.set_busy(True)
        self.cancel_event.clear()
        self.status.set("Checking link...")
        threading.Thread(target=self._info_worker, args=(url,), daemon=True).start()

    def _fetch_info(self, url):
        real = resolve_short(url)
        opts = build_options("video", None, "mp4", HERE, self.ffmpeg_dir)
        opts.update({"skip_download": True, "format": "all", "ignore_no_formats_error": True})
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(real, download=False)
        if not info:
            raise ValueError("Could not read that link.")
        s = summarize_info(info)
        if s["playlist"]:
            raise ValueError("That is a playlist. Please paste a single video link.")
        if s["live"]:
            raise ValueError("Live streams are not supported.")
        if not s["has_video"] and not s["has_audio"] and not s["image"]:
            raise ValueError("No downloadable formats were found for this link.")
        return real, s

    def _remember_image(self, url, s):
        if s.get("image"):
            self.image_for = url
            self.image_info = {"url": s["image"]["url"],
                               "base": safe_name(f"{s['title']} [{s['vid']}]" if s["title"] != "(untitled)" else f"pin [{s['vid']}]")}
        else:
            self.image_for, self.image_info = None, None

    def _img_progress(self, got, total):
        if total:
            self.post("progress", got * 100 / total)
        self.post("status", f"Downloading image: {fmt_bytes(got)}" + (f" / {fmt_bytes(total)}" if total else ""))

    def _image_worker(self, url, folder):
        try:
            if self.image_for != url or not self.image_info:
                real, s = self._fetch_info(url)
                self._remember_image(url, s)
                if not self.image_info:
                    raise ValueError("This pin has no downloadable image.")
            path = download_image(self.image_info["url"], folder, self.image_info["base"],
                                  self._img_progress, self.cancel_event)
            self.post("file", path)
            self.post("log", f"Saved: {path}")
            self.post("progress", 100)
            self.post("done", "Done - image saved")
        except DownloadCancelled:
            self.post("log", "Cancelled.")
            self.post("done", "Cancelled")
        except Exception as ex:  # noqa: BLE001
            self.post("log", f"Error: {friendly_error(ex)}")
            self.post("done", "Failed")

    def _info_worker(self, url):
        try:
            real, s = self._fetch_info(url)
            self.info_url = url
            self._remember_image(url, s)
            self.post("info", s)
            self.post("done", "Link OK - choose a resolution")
        except Exception as ex:  # noqa: BLE001
            self.post("log", f"Error: {friendly_error(ex)}")
            self.post("done", "Could not read that link")

    def start(self):
        if self.busy:
            return
        v = self._validated()
        if not v:
            return
        url, folder = v
        mode, height = self._selected()
        container = "mkv" if self.container.get().startswith("MKV") else "mp4"
        if mode == "image":
            self._save_folder(folder)
            self.set_busy(True)
            self.cancel_event.clear()
            self.progress["value"] = 0
            self.last_file = None
            self.status.set("Starting...")
            threading.Thread(target=self._image_worker, args=(url, folder), daemon=True).start()
            return
        if mode == "mp3" and not self.ffmpeg_dir:
            self.log("ffmpeg missing - saving original audio instead of MP3.")
        if mode == "video" and not self.ffmpeg_dir:
            self.log("ffmpeg missing - only ready-made files (usually up to 720p) can be downloaded.")
        self._save_folder(folder)
        self.set_busy(True)
        self.cancel_event.clear()
        self.progress["value"] = 0
        self.last_file = None
        self.status.set("Starting...")
        threading.Thread(target=self._download_worker,
                         args=(url, mode, height, container, folder), daemon=True).start()

    def _hook(self, d):
        if self.cancel_event.is_set():
            raise DownloadCancelled("Cancelled by user")
        if d["status"] == "downloading":
            total = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
            done = d.get("downloaded_bytes") or 0
            if total:
                self.post("progress", done * 100 / total)
            vc = (d.get("info_dict") or {}).get("vcodec")
            part = "audio" if vc == "none" else "video"
            spd, eta = d.get("speed"), d.get("eta")
            self.post("status", f"Downloading {part}: {fmt_bytes(done)} / {fmt_bytes(total) if total else '?'}"
                                f"  |  {fmt_bytes(spd) + '/s' if spd else '-'}"
                                f"  |  ETA {eta if eta is not None else '-'}s")
        elif d["status"] == "finished":
            self.post("progress", 100)

    def _pp_hook(self, d):
        if d.get("status") == "started":
            name = d.get("postprocessor", "")
            self.post("status", "Converting to MP3..." if "ExtractAudio" in name else "Merging video and audio...")

    def _download_worker(self, url, mode, height, container, folder):
        try:
            if self.info_url != url:                 # make sure it is a single video
                real, _s = self._fetch_info(url)
            else:
                real = resolve_short(url)
            opts = build_options(mode, height, container, folder, self.ffmpeg_dir)
            opts["progress_hooks"] = [self._hook]
            opts["postprocessor_hooks"] = [self._pp_hook]
            opts["logger"] = QuietLogger(lambda m: self.post("log", m))
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(real, download=True)
            path = ((info or {}).get("requested_downloads") or [{}])[0].get("filepath")
            if path:
                self.post("file", path)
                self.post("log", f"Saved: {path}")
            self.post("progress", 100)
            self.post("done", "Done - download finished")
        except DownloadCancelled:
            self.post("log", "Cancelled.")
            self.post("done", "Cancelled")
        except Exception as ex:  # noqa: BLE001
            if self.cancel_event.is_set() or "DownloadCancelled" in str(ex):
                self.post("log", "Cancelled.")
                self.post("done", "Cancelled")
            else:
                self.post("log", f"Error: {friendly_error(ex)}")
                self.post("done", "Failed")


if __name__ == "__main__":
    App().mainloop()
