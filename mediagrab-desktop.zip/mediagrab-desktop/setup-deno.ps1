$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"      # makes downloads much faster
$base = "https://github.com/denoland/deno/releases/latest/download"
$zip  = "deno-x86_64-pc-windows-msvc.zip"
$tmp  = Join-Path $env:TEMP "mg_deno"
Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
New-Item $tmp -ItemType Directory | Out-Null
Invoke-WebRequest "$base/$zip" -OutFile "$tmp\$zip"
Invoke-WebRequest "$base/$zip.sha256sum" -OutFile "$tmp\sum.txt"
$m = Select-String -Path "$tmp\sum.txt" -Pattern '^Hash\s*:\s*([0-9A-Fa-f]{64})'
if (-not $m) { throw "Could not read the Deno checksum file" }
$expected = $m.Matches[0].Groups[1].Value
$actual = (Get-FileHash "$tmp\$zip" -Algorithm SHA256).Hash
if ($expected.ToLower() -ne $actual.ToLower()) { throw "Deno checksum mismatch - aborting" }
Expand-Archive "$tmp\$zip" -DestinationPath "$tmp\x"
New-Item "bin" -ItemType Directory -Force | Out-Null
Copy-Item "$tmp\x\deno.exe" "bin\deno.exe"
Remove-Item $tmp -Recurse -Force
Write-Host "Deno (JavaScript helper for YouTube) installed."
