# MediaGrab (desktop)

Paste a YouTube or Pinterest link -> Check link -> pick resolution + format + folder -> Download.
Real window, no server, no ports. Close the window and everything ends.

## Run (Windows)
1. Install Python 3.10+ once (python.org, tick "Add python.exe to PATH").
2. Double-click **MediaGrab.bat**. First launch installs inside this folder (1-2 min, once); after that it just opens.
3. To remove: delete the folder (and ~/.mediagrab.json, which only remembers your last save folder).

yt-dlp refreshes itself at most once per day at launch.

## Optional single .exe
GitHub -> Actions -> Build MediaGrab.exe -> Run workflow -> download the artifact. Rebuild monthly (exe can't update yt-dlp).

## Pinterest
Video pins download as video (MP4/MKV/MP3). Image pins download the original-size image (JPG/PNG/GIF/WebP).

## Options
- Resolution list = the real resolutions of that video (up to 4K/8K when available) + Best available + MP3 320 / original audio.
- MP4 = most compatible (prefers H.264 when it exists at your chosen height). MKV = keeps the best codecs untouched.
- To allow other sites, set RESTRICT_SITES = False at the top of app.py.

## Security
yt-dlp as a library (no shell), plugins off, YouTube/Pinterest allowlist, pin.it redirects re-validated, fixed filename
template, TLS on, no cookies, single videos only, nothing listens on the network.

## Limits
Playlists, live streams and Pinterest story/idea pins with several pages are not supported. Private/age-restricted videos need cookies (not supported by design).
Only download content you have the right to.
