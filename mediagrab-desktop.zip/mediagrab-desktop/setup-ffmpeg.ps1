$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"      # makes downloads much faster
$base = "https://github.com/BtbN/FFmpeg-Builds/releases/download/latest"
$zip  = "ffmpeg-master-latest-win64-gpl.zip"
$tmp  = Join-Path $env:TEMP "mg_ffmpeg"
Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
New-Item $tmp -ItemType Directory | Out-Null
Invoke-WebRequest "$base/$zip" -OutFile "$tmp\$zip"
Invoke-WebRequest "$base/checksums.sha256" -OutFile "$tmp\sums.txt"
$expected = ((Select-String -Path "$tmp\sums.txt" -Pattern ($zip + '$')).Line -split "\s+")[0]
$actual = (Get-FileHash "$tmp\$zip" -Algorithm SHA256).Hash
if ($expected.ToLower() -ne $actual.ToLower()) { throw "ffmpeg checksum mismatch - aborting" }
Expand-Archive "$tmp\$zip" -DestinationPath "$tmp\x"
New-Item "bin" -ItemType Directory -Force | Out-Null
$ff = Get-ChildItem "$tmp\x" -Recurse -Filter ffmpeg.exe | Select-Object -First 1
Copy-Item $ff.FullName "bin\ffmpeg.exe"
$fp = Get-ChildItem "$tmp\x" -Recurse -Filter ffprobe.exe | Select-Object -First 1
if ($fp) { Copy-Item $fp.FullName "bin\ffprobe.exe" }
Remove-Item $tmp -Recurse -Force
Write-Host "ffmpeg installed."
