@echo off
REM Double-click to open MediaGrab. First launch installs itself inside this folder (1-2 min, once).
setlocal
cd /d "%~dp0"
if exist ".venv\.ready2" goto :run

echo First launch: preparing MediaGrab (about 1-2 minutes, only once)...
set PY=
where py >nul 2>&1 && set PY=py -3
if not defined PY where python >nul 2>&1 && set PY=python
if not defined PY (
  echo Python 3.10+ is required. Install it from https://www.python.org/downloads/
  echo and tick "Add python.exe to PATH", then double-click MediaGrab.bat again.
  pause & exit /b 1
)
%PY% -m venv .venv || goto :err
".venv\Scripts\python.exe" -m pip install --upgrade pip >nul 2>&1
".venv\Scripts\python.exe" -m pip install -U -r requirements.txt || goto :err
if not exist "bin\ffmpeg.exe" powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup-ffmpeg.ps1" || goto :err
if not exist "bin\deno.exe" powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup-deno.ps1" || goto :err
> ".venv\.ready2" echo ok

:run
start "" ".venv\Scripts\pythonw.exe" app.py
exit /b 0

:err
echo.
echo SETUP FAILED - read the message above.
pause
exit /b 1
